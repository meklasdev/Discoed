const config = {
    registerGlobally: false,
};

module.exports = config;
