module.exports = {
    VERIFY_CHANNEL_ID: '1402678764923523267',
    VERIFY_ROLE_ID: '1402678555531284681',
    TIMEOUT_MS: 60 * 1000,
    DM_MESSAGE: `⛔ Your verification has been rejected.

To access the free items, you must **send TWO photos** confirming that you have completed the following steps:

- ✅ Follow TikTok: https://www.tiktok.com/@slientmafiatop
- ✅ Subscribe + like the video: https://www.youtube.com/watch?v=ZGsgOnOMpDs&t=26s

Please try again in 1 minute. Thank you! – Silent Maf1a <:silent:1395058293432516658>`,
    STICKY_MESSAGE: `### <a:yes:1253433659260669975> Verification - maximum 2 minutes.

-# To access our **Free Stuff**, please make sure you have completed **ALL** steps and attached **TWO clear and complete screenshots** as proof:

## <a:Verified_Purple_Animated:1382655410795843695> **Follow us on TikTok:** [www.tiktok.com/@slientmafiatop](https://www.tiktok.com/@slientmafiatop)

## <a:Verified_Purple_Animated:1382655410795843695> **Leave a like & sub on the channel:** [youtube.com/watch?v=DOBELRa6apA](https://www.youtube.com/watch?v=ZGsgOnOMpDs&t=26s)

-# Thank you for your support - Silent Maf1a <:silent:1395058293432516658>`
};
